package ProtocoloEnlace;

public class Constants { 
    public static final int buffersize = 3; 
    public static final int lostframes = 2;
    public static final int timeout = 1; 
}
